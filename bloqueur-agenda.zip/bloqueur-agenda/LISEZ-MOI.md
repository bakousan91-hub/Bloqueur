# Bloqueur Agenda

Appli Android : quand un événement de ton agenda contient « devoirs », « révision » ou « lecture » dans son titre, TikTok, Insta, Snap, YouTube, etc. sont bloqués (retour à l'écran d'accueil).

## Obtenir l'APK (sans Android Studio)

1. Crée un compte sur github.com et un nouveau dépôt (repository) vide, nommé `bloqueur-agenda`.
2. Envoie-y tout le contenu de ce dossier (y compris le dossier caché `.github`).
3. Va dans l'onglet **Actions** → « Construire l'APK » → **Run workflow**.
4. Quand c'est vert (quelques minutes), ouvre l'exécution et télécharge **bloqueur-agenda-apk**. Dézippe : tu obtiens `app-debug.apk`.

## Installer sur le Samsung

1. Ouvre `app-debug.apk` sur le téléphone, autorise l'installation depuis cette source si Android le demande.
2. Si Play Protect avertit, c'est normal : l'appli n'est pas sur le Play Store.

## Réglages au premier lancement

1. « Autoriser l'accès à l'agenda » → Autoriser.
2. « Activer le blocage » → Applis installées / Applis téléchargées → Bloqueur Agenda → activer.
   (Sur Samsung, il faut parfois confirmer un avertissement : l'appli lit seulement le nom de l'appli qui s'ouvre.)
3. Coche les applis à bloquer, vérifie les mots-clés, et regarde la ligne « Mode travail en ce moment ».

## Limites

- Le blocage peut se désactiver dans les paramètres d'accessibilité : le **mode strict** bloque aussi les Paramètres pendant le travail.
- Code non testé sur un vrai téléphone : à corriger ensemble si besoin.
